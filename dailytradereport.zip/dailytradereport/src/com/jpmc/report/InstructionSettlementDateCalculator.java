package com.jpmc.report;

/**
* @author SubhraKP
*
*/
import com.jpmc.instruction.Instruction;
import com.jpmc.workingday.ArabiaWorkingDays;
import com.jpmc.workingday.DefaultWorkingDays;
import com.jpmc.workingday.WorkingDays;
import java.time.LocalDate;
import java.util.Currency;
import java.util.Set;

/**
 * A settlement date calculator
 */
public class InstructionSettlementDateCalculator {

    /**
     * Helper method to calculate settlement date for every given instruction
     */
    public static void calculateSettlementDates(Set<Instruction> instructions) {
        instructions.forEach(InstructionSettlementDateCalculator::calculateSettlementDate);
    }

    /**
     * Calculate the settlementDate Based on Country Currency
     */
    public static void calculateSettlementDate(Instruction instruction) {
        // Select proper strategy based on the Currency
        final WorkingDays workingDaysMechanism = getWorkingDaysStrategy(instruction.getCurrency());

        // find the correct settlement date
        final LocalDate newSettlementDate =
                workingDaysMechanism.findFirstWorkingDate(instruction.getSettlementDate());

        if (newSettlementDate != null) {
            // set the correct settlement date
            instruction.setSettlementDate(newSettlementDate);
        }
    }

    /*****Finds Working day by Currency******/
    private static WorkingDays getWorkingDaysStrategy(Currency currency) {
        if ((currency.getCurrencyCode().equalsIgnoreCase("AED")) ||
            (currency.getCurrencyCode().equalsIgnoreCase("SAR")))
        {
            return ArabiaWorkingDays.getInstance();
        }
        return DefaultWorkingDays.getInstance();
    }
}
