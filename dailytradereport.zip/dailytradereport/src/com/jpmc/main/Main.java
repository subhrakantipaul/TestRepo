package com.jpmc.main;


/**
* @author SubhraKP
*
*/
import com.jpmc.instruction.DumyInstructionsGenerator;
import com.jpmc.instruction.Instruction;
import com.jpmc.report.ReportGenerator;
import java.util.Set;

public class Main {

    public static void main(String[] args) {
        final Set<Instruction> instructions = DumyInstructionsGenerator.getDumyInstructions();
        ReportGenerator reportGenerator = new ReportGenerator();

        System.out.println(reportGenerator.generateInstructionsReport(instructions));
    }
}
