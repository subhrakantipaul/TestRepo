package com.jpmc.workingday;


/**
* @author SubhraKP
*
*/

import java.time.DayOfWeek;

public class ArabiaWorkingDays extends WorkingDaysImpl {

    private static ArabiaWorkingDays instance = null;

    public static ArabiaWorkingDays getInstance() {
        if (instance == null) {
            instance = new ArabiaWorkingDays();
        }
        return instance;
    }

    private ArabiaWorkingDays() {
        super();
    }

    @Override
    protected void setupWorkingDays() {
        this.isWorkingDayMap.put(DayOfWeek.SUNDAY, true);
        this.isWorkingDayMap.put(DayOfWeek.MONDAY, true);
        this.isWorkingDayMap.put(DayOfWeek.TUESDAY, true);
        this.isWorkingDayMap.put(DayOfWeek.WEDNESDAY, true);
        this.isWorkingDayMap.put(DayOfWeek.THURSDAY, true);
        this.isWorkingDayMap.put(DayOfWeek.FRIDAY, false); //Not Working Day in Arabia
        this.isWorkingDayMap.put(DayOfWeek.SATURDAY, false); //Not Working Day in Arabia
    }
}
