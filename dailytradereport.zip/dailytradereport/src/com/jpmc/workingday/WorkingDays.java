package com.jpmc.workingday;

/**
* @author SubhraKP
*
*/
import java.time.LocalDate;

public interface WorkingDays {
    public LocalDate findFirstWorkingDate(LocalDate date);
}
