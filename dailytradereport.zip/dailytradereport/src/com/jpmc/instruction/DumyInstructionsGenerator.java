package com.jpmc.instruction;

/**
 * @author SubhraKP
 *
 */
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Currency;
import java.util.HashSet;
import java.util.Set;

public class DumyInstructionsGenerator {
	
	//Generating  Set of instructions by passing  value through  constructor
    public static Set<Instruction> getDumyInstructions() {
        return new HashSet<>(Arrays.asList(


			 new Instruction(
                "FOO",
                TradeAction.BUY,
                Currency.getInstance("AUD"),
                LocalDate.of(2016, 1, 1),
                LocalDate.of(2017, 1, 2),
                BigDecimal.valueOf(0.50),
                200,
                BigDecimal.valueOf(100.25)),
	
	         new Instruction(
                "BAR",
                TradeAction.SELL,
                Currency.getInstance("AED"),
                LocalDate.of(2016, 1, 5),
                LocalDate.of(2016, 1, 7),
                BigDecimal.valueOf(0.22),
                450,
                BigDecimal.valueOf(150.5)),
			
        		
        	new Instruction(
                "JPMC",
                TradeAction.BUY,
                Currency.getInstance("AUD"),
                LocalDate.of(2016, 3, 10),
                LocalDate.of(2016, 3, 20),
                BigDecimal.valueOf(0.50),
                200,
                BigDecimal.valueOf(100.25)),

            new Instruction(
                "MS",
                TradeAction.SELL,
                Currency.getInstance("EUR"),
                LocalDate.of(2016, 3, 10),
                LocalDate.of(2016, 3, 21),
                BigDecimal.valueOf(0.34),
                100,
                BigDecimal.valueOf(400.6)),

            new Instruction(
                "BOA",
                TradeAction.BUY,
                Currency.getInstance("EUR"),
                LocalDate.of(2017, 3, 10),
                LocalDate.of(2017, 3, 21),
                BigDecimal.valueOf(0.34),
                20,
                BigDecimal.valueOf(40.6)),

            new Instruction(
                "ANZ",
                TradeAction.SELL,
                Currency.getInstance("EUR"),
                LocalDate.of(2017, 3, 10),
                LocalDate.of(2017, 3, 21),
                BigDecimal.valueOf(0.34),
                1000,
                BigDecimal.valueOf(160.6)),

            new Instruction(
                "RBS",
                TradeAction.SELL,
                Currency.getInstance("EUR"),
                LocalDate.of(2017, 3, 10),
                LocalDate.of(2017, 3, 21),
                BigDecimal.valueOf(0.34),
                120,
                BigDecimal.valueOf(500.6))
        ));
    }
}
