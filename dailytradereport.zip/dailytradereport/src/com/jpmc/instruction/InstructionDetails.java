package com.jpmc.instruction;

/**
 * @author SubhraKP
 *
 */


import java.math.BigDecimal;
import java.util.Currency;

/*
*  Price Details of any Trancation
*/


public class InstructionDetails {

	 //currency of Transaction
    private final Currency currency;

    //Foreign exchange rate with respect to USD which was agreed ie aggreedfx
    private final BigDecimal agreedFx;

    //Units of shares to be bought or sold
    private final Integer units;

    //price per unit
    private final BigDecimal pricePerUnit;

    //Total Amount Traded in USD
    private final BigDecimal totalTradeAmount;

    InstructionDetails(Currency currency, BigDecimal agreedFx, Integer units, BigDecimal pricePerUnit) {
        this.currency = currency;
        this.agreedFx = agreedFx;
        this.units = units;
        this.pricePerUnit = pricePerUnit;
        this.totalTradeAmount = calculateAmount(this);
    }

    
	public BigDecimal getAgreedFx() {
        return agreedFx;
    }

    public Integer getUnits() {
        return units;
    }

    public BigDecimal getPricePerUnit() {
        return pricePerUnit;
    }

    public BigDecimal getTradeAmount() {
        return totalTradeAmount;
    }

    public Currency getCurrency() {
        return currency;
    }
    
    //calculating as per formula : USD amount of a trade = Price per unit * Units * Agreed Fx
    private static BigDecimal calculateAmount(InstructionDetails instructionDetails) {
        return instructionDetails.getPricePerUnit().multiply(BigDecimal.valueOf(instructionDetails.getUnits())
            .multiply(instructionDetails.getAgreedFx()));
    	
    }
    
    
}
