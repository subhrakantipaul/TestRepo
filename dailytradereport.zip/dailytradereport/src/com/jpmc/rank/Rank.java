package com.jpmc.rank;

/**
 * @author SubhraKP
 *
 */

import java.time.LocalDate;

public class Rank {
    private final int rank;
    private final String entity;
    private final LocalDate date;

    public Rank(int rank, String entity, LocalDate date) {
        this.rank = rank;
        this.entity = entity;
        this.date = date;
    }

    public int getRank() {
        return rank;
    }

    public String getEntity() {
        return entity;
    }

    public LocalDate getDate() {
        return date;
    }

   
    
    

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((entity == null) ? 0 : entity.hashCode());
		result = prime * result + rank;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rank other = (Rank) obj;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (entity == null) {
			if (other.entity != null)
				return false;
		} else if (!entity.equals(other.entity))
			return false;
		if (rank != other.rank)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Rank [rank=" + rank + ", entity=" + entity + ", date=" + date
				+ "]";
	}

	
	
}
